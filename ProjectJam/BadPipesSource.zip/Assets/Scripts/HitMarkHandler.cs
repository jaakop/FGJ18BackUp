﻿using UnityEngine;

public class HitMarkHandler : MonoBehaviour
{
	public void Start ()
    {
        Destroy(gameObject, 10);
	}
}
